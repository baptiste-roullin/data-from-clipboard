var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/my-command.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/my-command.js":
/*!***************************!*\
  !*** ./src/my-command.js ***!
  \***************************/
/*! exports provided: onStartup, onShutdown, onSupplyTextFromClipboard, onSupplyRandomTextFromClipboard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onStartup", function() { return onStartup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyTextFromClipboard", function() { return onSupplyTextFromClipboard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyRandomTextFromClipboard", function() { return onSupplyRandomTextFromClipboard; });
// documentation: https://developer.sketchapp.com/reference/api/
//import { log } from 'console'
var sketch = __webpack_require__(/*! sketch */ "sketch");

var DataSupplier = sketch.DataSupplier;

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var util = __webpack_require__(/*! util */ "util");

function onStartup() {
  DataSupplier.registerDataSupplier("public.text", "Text from clipboard", "SupplyTextFromClipboard");
  DataSupplier.registerDataSupplier("public.text", "Random text from clipboard", "SupplyRandomTextFromClipboard");
}
function onShutdown() {
  // Deregister the plugin
  DataSupplier.deregisterDataSuppliers();
}

function shuffleArray(array) {
  for (var i = array.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * i);
    var temp = array[i];
    array[i] = array[j];
    array[j] = temp;
  }

  return array;
}

function onSupplyTextFromClipboard(context) {
  supplyOrderedData(context, getPasteBoardData(context));
}
;
function onSupplyRandomTextFromClipboard(context) {
  supplyRandomData(context, getPasteBoardData(context));
}
;

function getPasteBoardData(context) {
  var pasteboard = NSPasteboard.generalPasteboard();
  var supportedPasteboardTypes = ["public.rtf", "public.string", "public.plain-text", "public.utf8-plain-text", "public.multipleTextSelection", "public.html", "com.apple.traditional-mac-plain-text", "org.mozilla.custom-clipdata", "org.chromium.web-custom-data", "NSStringPboardType", "public.utf16-external-plain-text", "public.utf16-plain-text", "com.apple.iWork.TSPNativeData", "public.text", "com.apple.webarchive", "com.adobe.pdf", "com.microsoft.word.doc", "com.microsoft.excel.xls", "com.microsoft.powerpoint.ppt"]; // test wether pasteboard not empty

  if (pasteboard.pasteboardItems().count() > 0) {
    var pasteboardType = pasteboard.pasteboardItems().firstObject().types().firstObject(); //console.log(pasteboardType, supportedPasteboardTypes.indexOf(String(pasteboardType)))
    // test wether content is text

    if (supportedPasteboardTypes.indexOf(String(pasteboardType)) > -1) {
      var clipboardString = pasteboard.pasteboardItems().firstObject().stringForType(NSPasteboardTypeString); //console.log(/\n\n/.test(clipboardString));

      var clipboardArray = clipboardString.replace(/\n+/, "\n").split(/\n/g);
      return clipboardArray;
    } else {
      UI.message("Content in clipboard is not text"); //console.log(pasteboard.pasteboardItems().firstObject().stringForType(NSPasteboardTypeString))

      return false;
    }
  } else {
    UI.message("Clipboard is empty");
    return false;
  }
}

function replaceSelection(context, newData) {
  util.toArray(context.data.items).map(sketch.fromNative).forEach(function (item, i) {
    var selection = "";

    if (item.type === "DataOverride") {
      selection = item.value;
    } else {
      selection = item.text;
    }

    var line = i % newData.length;
    DataSupplier.supplyDataAtIndex(context.data.key, newData[line], i);
  });
}

function supplyOrderedData(context, newData) {
  if (!newData) {
    return;
  }

  replaceSelection(context, newData);
}

function supplyRandomData(context, newData) {
  if (!newData) {
    return;
  }

  var shufflednewData = shuffleArray(newData);
  replaceSelection(context, shufflednewData);
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onStartup'] = __skpm_run.bind(this, 'onStartup');
globalThis['onShutdown'] = __skpm_run.bind(this, 'onShutdown');
globalThis['onSupplyTextFromClipboard'] = __skpm_run.bind(this, 'onSupplyTextFromClipboard');
globalThis['onSupplyRandomTextFromClipboard'] = __skpm_run.bind(this, 'onSupplyRandomTextFromClipboard');
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=my-command.js.map